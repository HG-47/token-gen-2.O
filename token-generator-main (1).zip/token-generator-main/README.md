# token-generator
Discord Token Generator


Hey!
This is a working Discord Token Generator (7/9/2023) which will generate Discord Tokens.

Requirements:
✓ CapSolver Key ‣ https://capsolver.com/
✓ Proxies ‣ https://proxies.gg/

To-Do:
• Add your Proxies in 'input/proxies.txt'
• Add your CapSolver-Key in 'config.json'
• Run 'main.py'

THIS TOKEN GENERATOR IS NOT MADE BY ME

> IM NOT SURE IF CAPMONSTER IS WORKING
